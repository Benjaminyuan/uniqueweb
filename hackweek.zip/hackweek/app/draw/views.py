from . import draw
from flask import render_template
@draw.route('/')
def drawl_main():
    return render_template('draw.html')