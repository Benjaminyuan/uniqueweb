$(function(){
    $('#option2-1').attr('checked','checked');
    $('#opt2-label1').removeClass('btn-default')
    .addClass('on');
    $('input[name="options-2]').on('change',function(){
        this.parent().removeClass('btn-default')
            .addClass('on').siblings().removeClass('on')
            .addClass('btn-default');
    })
    // $('#option2-1').on('change',function(){
    //     $('#opt2-label1').removeClass('btn-default')
    //     .addClass('on').siblings().removeClass('on')
    //     .addClass('btn-default');
    // })
    // $('#option2-2').on('change',function(){
    //     $('#opt2-label2').removeClass('btn-default')
    //     .addClass('on').siblings().removeClass('on')
    //     .addClass('btn-default');
    // })
    // $('#option2-3').on('change',function(){
    //     $('#opt2-label3').removeClass('btn-default')
    //     .addClass('on').siblings().removeClass('on')
    //     .addClass('btn-default');
    // })
    $('#option3-1').attr('checked','checked');
    $('#opt3-label1').removeClass('btn-default')
    .addClass('on');
    $('input[name="options-3]').on('change',function(){
        this.parent().removeClass('btn-default')
            .addClass('on').siblings().removeClass('on')
            .addClass('btn-default');
    })
    // $('#option3-1').on('change',function(){
    //     $('#opt3-label1').removeClass('btn-default')
    //     .addClass('on').siblings().removeClass('on')
    //     .addClass('btn-default');
    //     console.log('change!');
    // })
    // $('#option3-2').on('change',function(){
    //     $('#opt3-label2').removeClass('btn-default')
    //     .addClass('on').siblings().removeClass('on')
    //     .addClass('btn-default');
    //     console.log('change!');
    // })
    // $('#option3-3').on('change',function(){
    //     $('#opt3-label3').removeClass('btn-default')
    //     .addClass('on').siblings().removeClass('on')
    //     .addClass('btn-default');
    //     console.log('change!');
    // })
    $('#sub-Btn').click(function(){
        console.log('click1');
    });
    $('#sub-Btn').on("click",function (){
        console.log('click');
        var form={};
        form['select-1'] = $('select[name="select-1"] option:selected').val();
        form['select-2'] = $('select[name="select-2"] option:selected').val();
        form['select-3'] = $('select[name="select-3"] option:selected').val();
        form['select-4'] = $('select[name="select-4"] option:selected').val();
        form['select-5'] = $('radio[name="options-2"] checked').val();
        form['select-6'] = $('radio[name="options-3"] checked').val();
        console.log(form);
        $.ajax({
            url:"{{url_for('data_load')}}",
            type:"post",
            data: form,
            datatype:'json',
            success:function(data){
                $('mainimg').attr('src',data.img_url);   
            },
            error:function(){
                $('mainimg').attr('src','/static/pic/comic.jpg');
            }
        })
    }); 
}
);
function up_load(){
    console.log('click');
    var form={};
    form['select-1'] = $('select[name="select-1"] option:selected').val();
    form['select-2'] = $('select[name="select-2"] option:selected').val();
    form['select-3'] = $('select[name="select-3"] option:selected').val();
    form['select-4'] = $('select[name="select-4"] option:selected').val();
    form['select-5'] = $('radio[name="options-2"] checked').val();
    form['select-6'] = $('radio[name="options-3"] checked').val();
    console.log(form);
    $.ajax({
        url:"{{url_for('data_load')}}",
        type:"post",
        data: form,
        datatype:'json',
        success:function(data){
            $('mainimg').attr('src',data.img_url);   
        },
        error:function(){
            $('mainimg').attr('src','/static/pic/comic.jpg');
        }
    })
}