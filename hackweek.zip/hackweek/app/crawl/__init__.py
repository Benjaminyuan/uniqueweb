from flask import Blueprint

crawl = Blueprint('crawl',__name__)

import app.crawl.views


